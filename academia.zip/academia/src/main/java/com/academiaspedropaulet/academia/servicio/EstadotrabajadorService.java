package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Estadotrabajador;
import com.academiaspedropaulet.academia.modelo.Estadotrabajador;

import java.util.List;
import java.util.Map;

public interface EstadotrabajadorService extends CrudGenericoService<Estadotrabajador, Long> {

}
