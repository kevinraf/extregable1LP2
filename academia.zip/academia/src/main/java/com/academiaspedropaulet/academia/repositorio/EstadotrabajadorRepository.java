package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Estadotrabajador;

public interface EstadotrabajadorRepository extends CrudGenericoRepository<Estadotrabajador, Long> {
}
