package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Comunicado;
import com.academiaspedropaulet.academia.modelo.Comunicado;

import java.util.List;
import java.util.Map;

public interface ComunicadoService extends CrudGenericoService<Comunicado, Long> {

}
