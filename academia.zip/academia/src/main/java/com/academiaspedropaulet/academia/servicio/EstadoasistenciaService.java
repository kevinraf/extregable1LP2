package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Estadoasistencia;
import com.academiaspedropaulet.academia.modelo.Estadoasistencia;

import java.util.List;
import java.util.Map;

public interface EstadoasistenciaService extends CrudGenericoService<Estadoasistencia, Long> {

}
