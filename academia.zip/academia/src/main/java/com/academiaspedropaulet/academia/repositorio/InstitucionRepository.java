package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Institucion;

public interface InstitucionRepository extends CrudGenericoRepository<Institucion, Long> {
}
