package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Periodo;
import com.academiaspedropaulet.academia.modelo.Periodo;

import java.util.List;
import java.util.Map;

public interface PeriodoService extends CrudGenericoService<Periodo, Long> {


}
