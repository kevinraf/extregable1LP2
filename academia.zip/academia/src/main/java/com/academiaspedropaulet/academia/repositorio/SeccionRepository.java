package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Seccion;

public interface SeccionRepository extends CrudGenericoRepository<Seccion, Long> {
}
