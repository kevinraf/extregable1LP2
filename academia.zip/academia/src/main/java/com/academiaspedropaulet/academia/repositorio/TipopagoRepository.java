package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Tipopago;

public interface TipopagoRepository extends CrudGenericoRepository<Tipopago, Long>{
}
