package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Nota;

public interface NotaRepository extends CrudGenericoRepository<Nota, Long> {
}
