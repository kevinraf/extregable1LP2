package com.academiaspedropaulet.academia.servicio;


import com.academiaspedropaulet.academia.modelo.Libreta;
import com.academiaspedropaulet.academia.modelo.Libreta;

import java.util.List;
import java.util.Map;

public interface LibretaService extends CrudGenericoService<Libreta, Long> {

}
