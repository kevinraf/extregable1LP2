package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Turno;
import com.academiaspedropaulet.academia.modelo.Turno;

import java.util.List;
import java.util.Map;

public interface TurnoService extends CrudGenericoService<Turno, Long> {

}

