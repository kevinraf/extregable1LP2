package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Estadoasistencia;

public interface EstadoasistenciaRepository extends CrudGenericoRepository<Estadoasistencia, Long> {
}
