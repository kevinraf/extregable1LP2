package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Grupo;

public interface GrupoRepository extends CrudGenericoRepository<Grupo, Long> {
}
