package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Trabajador;

public interface TrabajadorRepository extends CrudGenericoRepository<Trabajador, Long> {
}
