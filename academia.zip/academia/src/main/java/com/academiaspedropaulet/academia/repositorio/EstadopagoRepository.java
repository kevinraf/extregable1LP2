package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Estadopago;

public interface EstadopagoRepository extends CrudGenericoRepository<Estadopago, Long> {
}
