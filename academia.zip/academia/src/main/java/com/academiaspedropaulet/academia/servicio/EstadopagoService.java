package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Estadopago;
import com.academiaspedropaulet.academia.modelo.Estadopago;
import com.academiaspedropaulet.academia.modelo.Estadotrabajador;

import java.util.List;
import java.util.Map;

public interface EstadopagoService extends CrudGenericoService<Estadopago, Long> {

}
