package com.academiaspedropaulet.academia.servicio;


import com.academiaspedropaulet.academia.modelo.Asunto;

import java.util.List;
import java.util.Map;

public interface AsuntoService extends CrudGenericoService <Asunto, Long> {

}
