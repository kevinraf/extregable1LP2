package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Sedeinstitucion;

public interface SedeinstitucionRepository extends CrudGenericoRepository<Sedeinstitucion, Long> {
}
