package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.Cupo;
import com.academiaspedropaulet.academia.modelo.Cupo;

import java.util.List;
import java.util.Map;

public interface CupoService extends CrudGenericoService<Cupo, Long> {

}
