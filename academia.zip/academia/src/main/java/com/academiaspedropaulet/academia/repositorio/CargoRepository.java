package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Cargo;

public interface CargoRepository extends CrudGenericoRepository<Cargo, Long> {
}
