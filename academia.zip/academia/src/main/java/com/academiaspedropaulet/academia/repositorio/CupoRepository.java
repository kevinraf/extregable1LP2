package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Cupo;

public interface CupoRepository extends CrudGenericoRepository<Cupo, Long> {
}
