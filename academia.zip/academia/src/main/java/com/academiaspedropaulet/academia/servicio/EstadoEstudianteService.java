package com.academiaspedropaulet.academia.servicio;

import com.academiaspedropaulet.academia.modelo.EstadoEstudiante;
import com.academiaspedropaulet.academia.modelo.EstadoEstudiante;

import java.util.List;
import java.util.Map;

public interface EstadoEstudianteService extends CrudGenericoService<EstadoEstudiante, Long> {

}
