package com.academiaspedropaulet.academia.repositorio;

import com.academiaspedropaulet.academia.modelo.Estudiante;

public interface EstudianteRepository extends CrudGenericoRepository<Estudiante, Long> {
}
